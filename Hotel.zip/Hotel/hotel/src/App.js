import Controller from "./components/controller";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
	return <Controller />;
}

export default App;
