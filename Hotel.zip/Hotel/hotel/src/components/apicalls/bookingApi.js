import { ResponseChk, ErrorChk } from "./checkapi";
let url = process.env.REACT_APP_API_URL + "/bookings";

export function getBooking() {
    const data = fetch(url).then(ResponseChk).catch(ErrorChk);
    return data;
}

export function validateRequest(book) {
    const val = book.room;
    let rmcnt = 0;
    // console.log(val);
    return fetch(url + "?room=" + val).then((response) => {
        if (!response.ok)
            throw new Error("Bookings cannot be retrieved ..error");
        return response.json().then((booking) => {
            // console.log(booking.length);
            // console.log(new Date(booking[0].checkin));
            
            for (let i = 0; i < booking.length; i++) {
                if (
                    new Date(booking[i].checkin) >= book.checkout.getTime() &&
                    new Date(booking[i].checkout) <= book.checkin.getTime()
                )
                    continue;
                else rmcnt += parseInt(booking[i].noofrooms);
            }
            rmcnt += parseInt(book.noofrooms)
            console.log(rmcnt);
            const ret = rmcnt > 10 ? false : true;
            console.log(ret);
            if(!ret)
                throw new Error ("Cannot fulfill this request...");
            else{
                return fetch(url, {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({
                        ...book,
                    }),
                }).then(ResponseChk).catch(ErrorChk);
            }
        });
    });
}

// export function addBooking(booking) {
//     validateRequest(booking)
//     // const ret = validateRequest(booking)
//     // console.log("inside addBooking api...")
//     // console.log(ret)
//     // debugger;
//     // if (!ret) 
//     //   throw new Error ("Cannot fulfill this request...");
//     // else{
//     //     debugger;
//     //     return fetch(url, {
//     //         method: "POST",
//     //         headers: { "content-type": "application/json" },
//     //         body: JSON.stringify({
//     //             ...booking,
//     //         }),
//     //     }).then(ResponseChk).catch(ErrorChk);
//     // }
    
// }

export function deleteBooking(deleteOrder) {
    fetch(url + "?email=" + deleteOrder.email).then((response) => {
        console.log(response)
        if (!response.ok)
            throw new Error("Entered data not found ..error")
        return response.json().then((order) => {
            let id = order[0].id;
            return fetch(url + "/" + id, ({
                method: "DELETE",
              })).then(ResponseChk).catch(ErrorChk);
        })
    })
}