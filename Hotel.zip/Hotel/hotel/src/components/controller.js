import React from "react";
import { Route, Switch, BrowserRouter } from "react-router-dom";
import Navbar from "./navbar/navbar";
import CarouselSlider from "./navbar/carousel";
import Rooms from "./body/rooms/rooms";
import Booking from "./body/bookings/booking";

function Controller() {
	return (
		<BrowserRouter>
			<Navbar />
			<Switch>
				<Route path="/" exact>
					<CarouselSlider />
				</Route>
				<Route path="/home">
					<CarouselSlider />
				</Route>
				<Route path="/features"></Route>
				<Route path="/rooms">
					<Rooms />
				</Route>
				<Route path="/about"></Route>
				<Route path="/contact"></Route>
				<Route path="/booking">
					<Booking />
				</Route>
			</Switch>
		</BrowserRouter>
	);
}

export default Controller;
