import React from "react";
import Card from "react-bootstrap/Card";
import Image from "react-bootstrap/Image";
import ps1 from "./img/ex11.jpg";
import js1 from "./img/js1.jpg";
import sd1 from "./img/sd1.jpg";
import d1 from "./img/d1.jpg";
import ex1 from "./img/ex1.jpg";
import "./rooms.css";
import { Link } from "react-router-dom";

function Rooms() {
	return (
		<>
			<div className="grid-container">
				<div>
					<Card>
						<Card.Header>
							<h2>Presidential Suite</h2>
						</Card.Header>
						<Card.Body>
							<div className="inner">
								<div>
									<Image src={ps1} rounded fluid />
								</div>
								<div className="content">
									Lorem ipsum dolor sit, amet consectetur
									adipisicing elit. Porro ullam qui odit
									molestiae in explicabo reprehenderit? Odio
									beatae eligendi aspernatur minima mollitia.
									Recusandae error odit aut voluptatibus
									asperiores nam beatae iusto earum facere
									itaque! Quasi earum molestias amet? Itaque
									consequatur excepturi est laudantium beatae?
									Accusamus fugiat, eius ab necessitatibus
									veritatis harum sapiente consequatur,
									tenetur eveniet minus cum qui omnis cumque,
									ratione modi est. Excepturi voluptatibus
									dolorum perferendis quam, eveniet est
									repudiandae natus rerum quae consequatur
									eius tenetur, maiores tempore in at quidem
									commodi soluta laborum harum minima officia
									libero aliquid quibusdam. Illo excepturi
									tempore laboriosam consectetur vero aut
									expedita illum.
									<br />
									<Link
										className="btn btn-primary"
										to="/booking"
									>
										Book Now
									</Link>
									
								</div>
							</div>
						</Card.Body>
					</Card>
				</div>

				<div>
					<Card>
						<Card.Header>
							<h2>Junior Suites</h2>
						</Card.Header>
						<Card.Body>
							<div className="inner">
								<div>
									<Image src={js1} rounded fluid />
								</div>
								<div>
									Lorem ipsum dolor sit, amet consectetur
									adipisicing elit. Porro ullam qui odit
									molestiae in explicabo reprehenderit? Odio
									beatae eligendi aspernatur minima mollitia.
									Recusandae error odit aut voluptatibus
									asperiores nam beatae iusto earum facere
									itaque! Quasi earum molestias amet? Itaque
									consequatur excepturi est laudantium beatae?
									Accusamus fugiat, eius ab necessitatibus
									veritatis harum sapiente consequatur,
									tenetur eveniet minus cum qui omnis cumque,
									ratione modi est. Excepturi voluptatibus
									dolorum perferendis quam, eveniet est
									repudiandae natus rerum quae consequatur
									eius tenetur, maiores tempore in at quidem
									commodi soluta laborum harum minima officia
									libero aliquid quibusdam. Illo excepturi
									tempore laboriosam consectetur vero aut
									expedita illum.
									<br />
									<Link
										className="btn btn-primary"
										to="/booking"
									>
										Book Now
									</Link>
								</div>
							</div>
						</Card.Body>
					</Card>
				</div>

				<div>
					<Card>
						<Card.Header>
							<h2>Executive</h2>
						</Card.Header>
						<Card.Body>
							<div className="inner">
								<div>
									<Image src={ex1} rounded fluid />
								</div>
								<div>
									Lorem ipsum dolor sit, amet consectetur
									adipisicing elit. Porro ullam qui odit
									molestiae in explicabo reprehenderit? Odio
									beatae eligendi aspernatur minima mollitia.
									Recusandae error odit aut voluptatibus
									asperiores nam beatae iusto earum facere
									itaque! Quasi earum molestias amet? Itaque
									consequatur excepturi est laudantium beatae?
									Accusamus fugiat, eius ab necessitatibus
									veritatis harum sapiente consequatur,
									tenetur eveniet minus cum qui omnis cumque,
									ratione modi est. Excepturi voluptatibus
									dolorum perferendis quam, eveniet est
									repudiandae natus rerum quae consequatur
									eius tenetur, maiores tempore in at quidem
									commodi soluta laborum harum minima officia
									libero aliquid quibusdam. Illo excepturi
									tempore laboriosam consectetur vero aut
									expedita illum.
									<br />
									<Link
										className="btn btn-primary"
										to="/booking"
									>
										Book Now
									</Link>
								</div>
							</div>
						</Card.Body>
					</Card>
				</div>

				<div>
					<Card>
						<Card.Header>
							<h2>Super Deluxe</h2>
						</Card.Header>
						<Card.Body>
							<div className="inner">
								<div>
									<Image src={sd1} rounded fluid />
								</div>
								<div>
									Lorem ipsum dolor sit, amet consectetur
									adipisicing elit. Porro ullam qui odit
									molestiae in explicabo reprehenderit? Odio
									beatae eligendi aspernatur minima mollitia.
									Recusandae error odit aut voluptatibus
									asperiores nam beatae iusto earum facere
									itaque! Quasi earum molestias amet? Itaque
									consequatur excepturi est laudantium beatae?
									Accusamus fugiat, eius ab necessitatibus
									veritatis harum sapiente consequatur,
									tenetur eveniet minus cum qui omnis cumque,
									ratione modi est. Excepturi voluptatibus
									dolorum perferendis quam, eveniet est
									repudiandae natus rerum quae consequatur
									eius tenetur, maiores tempore in at quidem
									commodi soluta laborum harum minima officia
									libero aliquid quibusdam. Illo excepturi
									tempore laboriosam consectetur vero aut
									expedita illum.
									<br />
									<Link
										className="btn btn-primary"
										to="/booking"
									>
										Book Now
									</Link>
								</div>
							</div>
						</Card.Body>
					</Card>
				</div>

				<div>
					<Card>
						<Card.Header>
							<h2>Deluxe</h2>
						</Card.Header>
						<Card.Body>
							<div className="inner">
								<div>
									<Image src={d1} rounded fluid />
								</div>
								<div>
									Lorem ipsum dolor sit, amet consectetur
									adipisicing elit. Porro ullam qui odit
									molestiae in explicabo reprehenderit? Odio
									beatae eligendi aspernatur minima mollitia.
									Recusandae error odit aut voluptatibus
									asperiores nam beatae iusto earum facere
									itaque! Quasi earum molestias amet? Itaque
									consequatur excepturi est laudantium beatae?
									Accusamus fugiat, eius ab necessitatibus
									veritatis harum sapiente consequatur,
									tenetur eveniet minus cum qui omnis cumque,
									ratione modi est. Excepturi voluptatibus
									dolorum perferendis quam, eveniet est
									repudiandae natus rerum quae consequatur
									eius tenetur, maiores tempore in at quidem
									commodi soluta laborum harum minima officia
									libero aliquid quibusdam. Illo excepturi
									tempore laboriosam consectetur vero aut
									expedita illum.
									<br />
									<Link
										className="btn btn-primary"
										to="/booking"
									>
										Book Now
									</Link>
								</div>
							</div>
						</Card.Body>
					</Card>
				</div>
			</div>
		</>
	);
}

export default Rooms;
