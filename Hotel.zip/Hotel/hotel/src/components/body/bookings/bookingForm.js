import React, { useState } from "react";
import PropTypes from "prop-types";
import moment from "moment";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import "./booking.css";

function BookingForm(props) {
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(new Date());

    function onCheckInDateChange(dateValue) {
        setStartDate(dateValue);
        props.handleDateChange("checkin", dateValue);
    }

    function onCheckOutDateChange(dateValue) {
        setEndDate(dateValue);
        props.handleDateChange("checkout", dateValue);
    }

    return (
        <div className="divide-container">
            <div>
                <form onSubmit={props.onSubmit}>
                    <div className="form-row">
                        <div className="form-group col-sm-12">
                            <div className="field">
                                <label>Full Name</label>
                                <input
                                    id="name"
                                    type="text"
                                    name="name"
                                    className="form-control"
                                    placeholder="Full Name"
                                    onChange={props.onChange}
                                    value={props.bookOrder.name}
                                />
                                {props.errors.name && (
                                    <div className="alert alert-danger">
                                        {props.errors.name}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="form-row">
                        <div className="form-group col-sm-12">
                            <div className="field">
                                <label>E-mail</label>
                                <input
                                    id="email"
                                    type="email"
                                    name="email"
                                    placeholder="E-mail"
                                    className="form-control"
                                    onChange={props.onChange}
                                    value={props.bookOrder.email}
                                />
                                {props.errors.email && (
                                    <div className="alert alert-danger">
                                        {props.errors.email}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="form-row">
                        <div className="form-group col-sm-6">
                            <div className="field">
                                <label>Room Type</label>
                                <select
                                    id="room"
                                    name="room"
                                    placeholder="Select Room Type"
                                    onChange={props.onChange}
                                    className="form-control"
                                    value={props.bookOrder.room}
                                >
                                    <option value="">Choose Room</option>
                                    <option value="Presidential Suite">
                                        Presidential Suite
                                    </option>
                                    <option value="Junior Suites">
                                        Junior Suites
                                    </option>
                                    <option value="Executive">Executive</option>
                                    <option value="Super Deluxe">
                                        Super Deluxe
                                    </option>
                                    <option value="Deluxe">Deluxe</option>
                                </select>
                                {props.errors.room && (
                                    <div className="alert alert-danger">
                                        {props.errors.room}
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="form-group col-sm-6">
                            <div className="field">
                                <label>Number of Rooms</label>
                                <select
                                    id="room"
                                    name="noofrooms"
                                    onChange={props.onChange}
                                    className="form-control"
                                    value={props.bookOrder.noofrooms}
                                >
                                    <option value="">Choose Room</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                </select>
                                {props.errors.noofrooms && (
                                    <div className="alert alert-danger">
                                        {props.errors.noofrooms}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="form-row">
                        <div className="form-group col-sm-6">
                            <label>Check-in Date</label>
                            <DatePicker
                                selected={startDate}
                                onChange={onCheckInDateChange}
                                dateFormat="dd/MM/yyyy"
                                monthsShown="1"
                                minDate={moment().toDate()}
                            />
                            {props.errors.checkin && (
                                <div className="alert alert-danger">
                                    {props.errors.checkin}
                                </div>
                            )}
                        </div>
                        <div className="form-group col-sm-6">
                            <label>Check-out Date</label>
                            <DatePicker
                                selected={endDate}
                                onChange={onCheckOutDateChange}
                                dateFormat="dd/MM/yyyy"
                                monthsShown="1"
                                minDate={moment().toDate()}
                            />
                            {props.errors.checkout && (
                                <div className="alert alert-danger">
                                    {props.errors.checkout}
                                </div>
                            )}
                        </div>
                    </div>
                    <button
                        type="submit"
                        className="btn btn-primary col-sm-12"
                        style={{ width: "100%" }}
                    >
                        Book Now
                    </button>
                </form>
            </div>
            <div>
                <h1>Terms and Condition</h1>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    Velit accusamus veritatis aut doloribus eaque ducimus
                    laudantium placeat quae unde debitis, eum et, ab magni vero
                    ipsum sequi alias culpa. Nisi possimus tempora eos modi
                    voluptatum minima? Dolore, voluptate? Velit ipsum cum
                    quidem? Consequatur, tenetur earum deleniti vero aut rem
                    necessitatibus voluptates aliquid, atque, quo optio quae
                    similique temporibus voluptatibus corporis eos ipsam esse
                    nostrum excepturi et a libero. Fugit nihil fugiat expedita
                    enim quaerat dolorum animi aperiam, aspernatur perferendis
                    incidunt error obcaecati quis qui, vitae voluptatibus a? Id
                    doloremque illum dolore quam molestiae ut error at voluptate
                    harum maxime? Aliquid fugit adipisci non? Adipisci dicta
                    libero illum earum iusto eius fugiat omnis voluptatibus,
                    rerum quasi voluptatum aliquam repellat quibusdam.
                    Voluptatibus commodi, ipsa repellat quasi temporibus veniam
                    doloribus! Commodi placeat accusantium ipsum excepturi
                    obcaecati. Fuga facere repellendus repudiandae eveniet omnis
                    quae ad, molestiae tempore beatae saepe natus adipisci
                    voluptate fugiat esse quia, recusandae doloribus aperiam
                    illum maxime perspiciatis atque deleniti dignissimos?
                    Repellendus assumenda, facilis iusto facere ab quod fuga
                    dolorum est officiis? Doloremque dignissimos, quia qui illum
                    accusamus ipsam incidunt a eveniet animi distinctio, ullam,
                    voluptas magni aliquid! Eum harum tenetur recusandae?
                    Officia nam quod labore mollitia quas alias officiis
                    obcaecati.
                    <form onSubmit={props.onDelete}>
                        <div className="form-group col-sm-12">
                            <div className="field">
                                <label>E-mail</label>
                                <input
                                    id="email"
                                    type="email"
                                    name="email"
                                    placeholder="E-mail"
                                    className="form-control"
                                    onChange={props.onDeleteChange}
                                    value={props.deleteOrder.email}
                                />
                            </div>
                            <button
                                type="submit"
                                className="btn btn-primary col-sm-12"
                                style={{ width: "100%" }}
                            >
                                Delete
                            </button>
                        </div>
                    </form>
                </p>
            </div>
        </div>
    );
}

BookingForm.propTypes = {
    bookOrder: PropTypes.object.isRequired,
    onSubmit: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    handleDateChange: PropTypes.func.isRequired,
};

export default BookingForm;
